<?php
$to = "ivanovicaleksa96@gmail.com"; 

// Validiraj da li je poslano POST-om
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Uhvati podatke iz forme
    $name = htmlspecialchars($_POST["name"] ?? '');
    $email = htmlspecialchars($_POST["email"] ?? '');
    $phone = htmlspecialchars($_POST["phone"] ?? '');
    $date = htmlspecialchars($_POST["date"] ?? '');
    $destination = htmlspecialchars($_POST["destination"] ?? '');
    $duration = htmlspecialchars($_POST["duration"] ?? '');
    $passengers = htmlspecialchars($_POST["passengers"] ?? '');
    $message = htmlspecialchars($_POST["message"] ?? '');

    // Osnovna validacija
    if (empty($name) || empty($phone) || empty($destination)) {
        die("Please fill in all required fields.");
    }

    // Priprema sadržaja emaila
    $subject = "New Booking Request from $name";
    $body = "
        Name: $name\n
        Email: $email\n
        Phone: $phone\n
        Date: $date\n
        Destination: $destination\n
        Duration: $duration\n
        Passengers: $passengers\n
        Message: $message
    ";

    $headers = "From: noreply@yourdomain.com\r\n" .
               "Reply-To: $email\r\n" .
               "X-Mailer: PHP/" . phpversion();

    // Pošalji email
    if (mail($to, $subject, $body, $headers)) {
        echo "Request sent successfully!";
    } else {
        echo "Something went wrong. Try again later.";
    }
} else {
    echo "Invalid request method.";
}
?>
